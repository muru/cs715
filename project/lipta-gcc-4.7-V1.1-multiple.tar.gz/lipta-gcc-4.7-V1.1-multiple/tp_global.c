#include<stdio.h>

int *p;

int main()
{
	int a,b;
        int *q;
	p = q;
	printf("%d%d",p,q);
}
